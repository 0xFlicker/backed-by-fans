#!/bin/sh
set -eu

repo_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
workspace=$(mktemp -d "${TMPDIR:-/tmp}/onchain-render-e2e.XXXXXX")
trap 'rm -rf "$workspace"' EXIT HUP INT TERM

"$repo_root/scripts/new-renderer.sh" "$workspace/renderer"
"$repo_root/scripts/test-renderer.sh" "$workspace/renderer"

test -s "$workspace/renderer/renderer-package.json"
test -s "$workspace/renderer/renderer-gallery/index.html"

gallery_count=$(find "$workspace/renderer/renderer-gallery" -name '*.svg' | wc -l | tr -d ' ')
if [ "$gallery_count" -ne 6 ]; then
  printf 'Expected six gallery SVGs, found %s.\n' "$gallery_count" >&2
  exit 1
fi

printf 'Local end-to-end renderer test passed.\n'
