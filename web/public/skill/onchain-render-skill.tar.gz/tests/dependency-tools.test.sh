#!/bin/sh
set -eu

repo_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
check="$repo_root/scripts/check-dependencies.sh"
fixture=$(mktemp -d "${TMPDIR:-/tmp}/onchain-render-deps.XXXXXX")
trap 'rm -rf "$fixture"' EXIT HUP INT TERM

set +e
missing_output=$(PATH="$fixture" /bin/sh "$check" --json 2>&1)
missing_status=$?
set -e

if [ "$missing_status" -eq 0 ]; then
  printf 'Expected missing dependency check to fail.\n' >&2
  exit 1
fi
case "$missing_output" in
  *'"ready":false'*) ;;
  *) printf 'Missing dependency JSON did not report ready=false.\n' >&2; exit 1 ;;
esac

for tool in git bun forge cast anvil docker; do
  printf '#!/bin/sh\nexit 0\n' > "$fixture/$tool"
  chmod +x "$fixture/$tool"
done

ready_output=$(PATH="$fixture" /bin/sh "$check" --json)
case "$ready_output" in
  *'"ready":true'*) ;;
  *) printf 'Complete dependency JSON did not report ready=true.\n' >&2; exit 1 ;;
esac

printf 'Dependency tooling tests passed.\n'
