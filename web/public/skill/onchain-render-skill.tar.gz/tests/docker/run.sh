#!/bin/sh
set -eu

repo_root=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)

docker build -f "$repo_root/tests/docker/Dockerfile.clean" -t onchain-render-skill:clean "$repo_root"
docker build -f "$repo_root/tests/docker/Dockerfile.ready" -t onchain-render-skill:ready "$repo_root"

printf 'Docker dependency and end-to-end tests passed.\n'
