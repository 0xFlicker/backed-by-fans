#!/bin/sh
set -eu

repo_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
project=${1:-}

if [ -z "$project" ] || [ "${2:-}" != "" ]; then
  printf 'Usage: %s <renderer-project-directory>\n' "$0" >&2
  exit 2
fi

if [ ! -f "$project/foundry.toml" ]; then
  printf 'No Foundry renderer project found at %s\n' "$project" >&2
  exit 1
fi

"$repo_root/scripts/check-dependencies.sh"

printf '\nFormatting renderer...\n'
(CDPATH= cd -- "$project" && forge fmt --check)

printf '\nBuilding renderer...\n'
FOUNDRY_PROFILE=robinhood forge build --root "$project" --ignore-eip-3860

printf '\nRunning renderer tests...\n'
FOUNDRY_PROFILE=robinhood forge test --root "$project" -vv

package_path="$project/renderer-package.json"
gallery_path="$project/renderer-gallery"

printf '\nBuilding browser package...\n'
bun "$repo_root/scripts/build-package.ts" "$project" --output "$package_path"

printf '\nRendering representative gallery...\n'
bun "$repo_root/scripts/render-gallery.ts" "$package_path" --output "$gallery_path"

printf '\nLocal renderer workflow complete.\n'
printf 'Package: %s\n' "$package_path"
printf 'Gallery: %s/index.html\n' "$gallery_path"
printf 'Show the gallery to the creator. Passing checks do not approve the design.\n'
