#!/bin/sh
set -eu

repo_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
project=${1:-}

if [ -z "$project" ]; then
  printf 'Usage: %s <renderer-project-directory> [--membership-name name]\n' "$0" >&2
  exit 2
fi
shift

membership_name=
while [ "$#" -gt 0 ]; do
  case "$1" in
    --membership-name)
      if [ "$#" -lt 2 ] || [ -z "$2" ]; then
        printf '%s requires a value.\n' "$1" >&2
        exit 2
      fi
      membership_name=$2
      shift 2
      ;;
    *)
      printf 'Unknown option: %s\n' "$1" >&2
      exit 2
      ;;
  esac
done

if [ ! -f "$project/foundry.toml" ]; then
  printf 'No Foundry renderer project found at %s\n' "$project" >&2
  exit 1
fi

"$repo_root/scripts/check-dependencies.sh"

printf '\nFormatting renderer...\n'
(CDPATH= cd -- "$project" && forge fmt --check)

printf '\nBuilding renderer...\n'
FOUNDRY_PROFILE=robinhood forge build --root "$project" --ignore-eip-3860

printf '\nRunning renderer tests...\n'
FOUNDRY_PROFILE=robinhood forge test --root "$project" -vv

package_path="$project/renderer-package.json"
gallery_path="$project/renderer-gallery"

printf '\nBuilding browser package...\n'
if [ -n "$membership_name" ]; then
  bun "$repo_root/scripts/build-package.ts" "$project" \
    --membership-name "$membership_name" \
    --output "$package_path"
else
  bun "$repo_root/scripts/build-package.ts" "$project" --output "$package_path"
fi

printf '\nRendering representative gallery...\n'
bun "$repo_root/scripts/render-gallery.ts" "$package_path" --output "$gallery_path"

printf '\nLocal renderer workflow complete.\n'
printf 'Package: %s\n' "$package_path"
printf 'Gallery: %s/index.html\n' "$gallery_path"
printf 'Show the gallery to the creator. Passing checks do not approve the design.\n'
