#!/bin/sh
set -eu

mode=text
if [ "${1:-}" = "--json" ]; then
  mode=json
elif [ "${1:-}" != "" ]; then
  printf 'Usage: %s [--json]\n' "$0" >&2
  exit 2
fi

required_tools="git bun forge cast anvil"
optional_tools="docker"
missing_required=""

has_command() {
  command -v "$1" >/dev/null 2>&1
}

append_missing() {
  if [ -z "$missing_required" ]; then
    missing_required="$1"
  else
    missing_required="$missing_required $1"
  fi
}

for tool in $required_tools; do
  if ! has_command "$tool"; then
    append_missing "$tool"
  fi
done

if [ "$mode" = json ]; then
  printf '{"required":{'
  separator=""
  for tool in $required_tools; do
    if has_command "$tool"; then status=true; else status=false; fi
    printf '%s"%s":%s' "$separator" "$tool" "$status"
    separator=","
  done
  printf '},"optional":{'
  separator=""
  for tool in $optional_tools; do
    if has_command "$tool"; then status=true; else status=false; fi
    printf '%s"%s":%s' "$separator" "$tool" "$status"
    separator=","
  done
  printf '},"ready":'
  if [ -z "$missing_required" ]; then printf 'true'; else printf 'false'; fi
  printf '}\n'
else
  for tool in $required_tools; do
    if has_command "$tool"; then
      printf 'required  %-8s found\n' "$tool"
    else
      printf 'required  %-8s missing\n' "$tool"
    fi
  done
  for tool in $optional_tools; do
    if has_command "$tool"; then
      printf 'optional  %-8s found\n' "$tool"
    else
      printf 'optional  %-8s missing\n' "$tool"
    fi
  done
fi

if [ -n "$missing_required" ]; then
  if [ "$mode" = text ]; then
    printf '\nMissing required tools:%s\n' "$missing_required" >&2
    printf 'After explaining the installation to the user, run ./scripts/bootstrap.sh --install.\n' >&2
  fi
  exit 1
fi

if [ "$mode" = text ]; then
  printf '\nRenderer toolchain is ready.\n'
fi
