#!/bin/sh
set -eu

repo_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)

if "$repo_root/scripts/check-dependencies.sh" >/dev/null 2>&1; then
  "$repo_root/scripts/check-dependencies.sh"
  exit 0
fi

if [ "${1:-}" != "--install" ] || [ "${2:-}" != "" ]; then
  "$repo_root/scripts/check-dependencies.sh" || true
  printf '\nThis command can install missing Bun and Foundry tooling from their official installers.\n' >&2
  printf 'Review that action with the user, then run: %s --install\n' "$0" >&2
  exit 1
fi

if ! command -v git >/dev/null 2>&1; then
  printf 'Git is missing. Install it with the operating system package manager, then rerun this command.\n' >&2
  exit 1
fi

if ! command -v curl >/dev/null 2>&1; then
  printf 'curl is required to fetch the official Bun and Foundry installers.\n' >&2
  exit 1
fi

if ! command -v bash >/dev/null 2>&1; then
  printf 'bash is required by the official Bun and Foundry installers.\n' >&2
  exit 1
fi

if ! command -v bun >/dev/null 2>&1; then
  if ! command -v unzip >/dev/null 2>&1; then
    printf 'unzip is required by the Bun installer. Install it with the operating system package manager, then rerun.\n' >&2
    exit 1
  fi
  printf 'Installing Bun with the official installer...\n'
  curl -fsSL https://bun.sh/install | bash
fi

if ! command -v forge >/dev/null 2>&1 || \
   ! command -v cast >/dev/null 2>&1 || \
   ! command -v anvil >/dev/null 2>&1; then
  printf 'Installing Foundry with the official installer...\n'
  curl -fsSL https://foundry.paradigm.xyz | bash
  if [ -x "${HOME}/.foundry/bin/foundryup" ]; then
    "${HOME}/.foundry/bin/foundryup"
  else
    printf 'Foundry installer completed but foundryup was not found. Open a new shell and rerun.\n' >&2
    exit 1
  fi
fi

PATH="${HOME}/.bun/bin:${HOME}/.foundry/bin:${PATH}"
export PATH
"$repo_root/scripts/check-dependencies.sh"
