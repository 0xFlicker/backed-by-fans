#!/bin/sh
set -eu

repo_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
target=${1:-}

if [ -z "$target" ] || [ "${2:-}" != "" ]; then
  printf 'Usage: %s <project-directory>\n' "$0" >&2
  exit 2
fi

if [ -d "$target" ] && [ -n "$(find "$target" -mindepth 1 -maxdepth 1 -print -quit)" ]; then
  printf 'Refusing to overwrite nonempty directory: %s\n' "$target" >&2
  exit 1
fi

mkdir -p "$target"
cp -R "$repo_root/template/." "$target/"
printf 'Renderer project created at %s\n' "$target"
printf 'Edit %s/src/CustomRenderer.sol, then run:\n' "$target"
printf '  %s/scripts/test-renderer.sh %s\n' "$repo_root" "$target"
