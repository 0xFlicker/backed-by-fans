# Contributing

Keep changes focused on making renderer creation easier, more understandable, or more reliable for creators and their agents.

Before opening a change:

1. Run `bun test`.
2. Run `./tests/dependency-tools.test.sh`.
3. Run `./tests/e2e-local.sh` when Foundry is available.
4. If dependency or bootstrap behavior changed, run `./tests/docker/run.sh`.

Do not add a renderer registry, cross-chain discovery, hosted image storage, backend signer, private-key workflow, or creator-facing proof language.
